# SNL_Complier

#### 1. lex_analysis：词法分析
- 读入SNL语言的源程序文件
- 输出token序列
#### 2. syn_analysis：LL1语法分析
- 输入token序列
- 输出语法树
#### 3. sem_analysis：语义分析
- 输入语法树
- 输出符号表

> Eg: 使用 `Codeblocks`打开